// src/data/promocoes.ts
import type { Promocao } from '@/logic/types/promocao';

export const PROMOCOES: Promocao[] = [
  {
    id: 'promo-001',
    titulo: 'Disney • Ingressos com 20% OFF (datas flexíveis)',
    descricao:
      'Economize nos parques Disney com ingresso flexível de 1 a 4 dias. Uso em até 7 dias a partir do primeiro dia.',
    precoOriginal: 650,
    precoComDesconto: 520,
    porcentagem: 20,
    categoria: 'parques',
    validade: 'Até 31/12/2025',
    parceiro: 'Parceiro Oficial',
  },
  {
    id: 'promo-002',
    titulo: 'Combo Refeições • Disney Springs',
    descricao:
      'Menu fixo (entrada + principal). Opções kid-friendly. Válido no almoço de 11h às 15h.',
    precoOriginal: 45,
    precoComDesconto: 32,
    porcentagem: 28,
    categoria: 'restaurantes',
    validade: 'Até 30/11/2025',
    parceiro: 'Restaurante Parceiro',
  },
  {
    id: 'promo-003',
    titulo: 'Hotel próximo ao Epcot com 30% OFF',
    descricao:
      'Diárias com café da manhã + transfer para parques. Cancelamento grátis até 48h antes.',
    precoOriginal: 220,
    precoComDesconto: 154,
    porcentagem: 30,
    categoria: 'hoteis',
    validade: 'Sujeito a disponibilidade',
    parceiro: 'Rede Hotel Parceira',
  },
  {
    id: 'promo-004',
    titulo: 'Outlet Premium: cupom extra +10%',
    descricao:
      'Cupom adicional em cima das lojas participantes (mínimo de compras pode se aplicar).',
    porcentagem: 10,
    categoria: 'compras',
    validade: 'Apenas fins de semana',
    parceiro: 'Outlet Premium',
  },
];
