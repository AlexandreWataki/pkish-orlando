// src/components/card/PromoCard.tsx
import React, { memo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import type { Promocao } from '@/logic/types/promocao';

const AZUL_NEON = '#00FFFF';
const AZUL_BORDA = '#00BFFF';
const AZUL_ESCURO = '#001F3F';

type Props = {
  item: Promocao;
  onPress?: (p: Promocao) => void;
};

function money(v?: number) {
  return typeof v === 'number' ? `US$ ${v.toFixed(2)}` : null;
}

const PromoCard = ({ item, onPress }: Props) => {
  const precoDe = money(item.precoOriginal);
  const precoPor = money(item.precoComDesconto);
  const badge = item.porcentagem ? `-${item.porcentagem}%` : undefined;

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={styles.card}
      onPress={() => onPress?.(item)}
    >
      {/* Thumb */}
      <View style={styles.left}>
        {item.imagem ? (
          typeof item.imagem === 'string' ? (
            <Image source={{ uri: item.imagem }} style={styles.thumb} />
          ) : (
            <Image source={item.imagem} style={styles.thumb} />
          )
        ) : (
          <View style={[styles.thumb, styles.thumbPlaceholder]}>
            <Text style={{ color: '#cce', fontSize: 12 }}>Imagem</Text>
          </View>
        )}
      </View>

      {/* Conteúdo */}
      <View style={styles.right}>
        <View style={styles.headerRow}>
          <Text numberOfLines={2} style={styles.title}>{item.titulo}</Text>
          {!!badge && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{badge}</Text>
            </View>
          )}
        </View>

        {item.parceiro ? <Text style={styles.parceiro}>{item.parceiro}</Text> : null}
        <Text numberOfLines={3} style={styles.desc}>{item.descricao}</Text>

        <View style={styles.priceRow}>
          {precoPor ? <Text style={styles.priceNow}>{precoPor}</Text> : null}
          {precoDe ? <Text style={styles.priceOld}>{precoDe}</Text> : null}
        </View>

        {item.validade ? (
          <Text style={styles.validade}>Validade: {item.validade}</Text>
        ) : null}
      </View>
    </TouchableOpacity>
  );
};

export default memo(PromoCard);

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    width: '92%',
    alignSelf: 'center',
    backgroundColor: AZUL_ESCURO,
    borderRadius: 20,
    padding: 12,
    marginVertical: 8,
    borderWidth: 2,
    borderColor: AZUL_BORDA,
    shadowColor: AZUL_NEON,
    shadowOpacity: 0.5,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  left: { width: 92, height: 92, marginRight: 12 },
  thumb: { width: '100%', height: '100%', borderRadius: 14 },
  thumbPlaceholder: {
    backgroundColor: '#0a2a4a',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: AZUL_BORDA,
  },
  right: { flex: 1 },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  title: { flex: 1, color: '#fff', fontWeight: '700', fontSize: 16 },
  badge: {
    marginLeft: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: AZUL_NEON,
    backgroundColor: '#032a3a',
  },
  badgeText: { color: AZUL_NEON, fontWeight: '800', fontSize: 12 },
  parceiro: { color: '#bfefff', fontSize: 12, marginTop: 2 },
  desc: { color: '#e6f7ff', fontSize: 13, marginTop: 6 },
  priceRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 10, marginTop: 10 },
  priceNow: { color: '#00ffea', fontWeight: '800', fontSize: 16 },
  priceOld: { color: '#a9cce3', textDecorationLine: 'line-through', fontSize: 13 },
  validade: { color: '#cce6ff', fontSize: 12, marginTop: 6 },
});
