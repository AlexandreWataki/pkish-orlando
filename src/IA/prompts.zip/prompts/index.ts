import type { DiaGerado } from '@/IA/gerarComIA';
import { toDiaGerado } from './toDiaGerado';

// Prompts (strings)
import CHEGADA from './chegada';
import DESCANSO from './descanso';
import COMPRAS from './compras';
import MK from './mk';
import AK from './ak';
import HS from './hs';
import EPCOT from './epcot';
import EPIC from './epic';
import ISLANDS from './islands';
import UNIVERSAL from './universal';
import SAIDA from './saida';

export const DIAS_WORD: Record<string, DiaGerado> = {
  CHEGADA: toDiaGerado(CHEGADA, {
    titulo: 'Chegada',
    tipo: 'chegada',
  }),
  DESCANSO: toDiaGerado(DESCANSO, {
    titulo: 'Descanso',
    tipo: 'descanso',
  }),
  COMPRAS: toDiaGerado(COMPRAS, {
    titulo: 'Compras',
    tipo: 'compras',
  }),
  MK: toDiaGerado(MK, {
    titulo: 'Magic Kingdom',
    tipo: 'parque',
    parque: 'MK',
  }),
  AK: toDiaGerado(AK, {
    titulo: 'Animal Kingdom',
    tipo: 'parque',
    parque: 'AK',
  }),
  HS: toDiaGerado(HS, {
    titulo: 'Hollywood Studios',
    tipo: 'parque',
    parque: 'HS',
  }),
  EPCOT: toDiaGerado(EPCOT, {
    titulo: 'EPCOT',
    tipo: 'parque',
    parque: 'EPCOT',
  }),
  EPIC: toDiaGerado(EPIC, {
    titulo: 'Epic Universe',
    tipo: 'parque',
    parque: 'EPIC',
  }),
  ISLANDS: toDiaGerado(ISLANDS, {
    titulo: 'Islands of Adventure',
    tipo: 'parque',
    parque: 'ISLANDS',
  }),
  UNIVERSAL: toDiaGerado(UNIVERSAL, {
    titulo: 'Universal Studios',
    tipo: 'parque',
    parque: 'UNIVERSAL',
  }),
  SAIDA: toDiaGerado(SAIDA, {
    titulo: 'Saída',
    tipo: 'saida',
  }),
};
